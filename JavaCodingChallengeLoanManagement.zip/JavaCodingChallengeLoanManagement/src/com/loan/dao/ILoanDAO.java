package com.loan.dao;

import java.sql.SQLException;
import java.util.List;

import com.loan.entity.Loan;
import com.loan.exception.InvalidLoanException;

public interface ILoanDAO {
	
	public void  applyLoan(Loan loan) throws SQLException,ClassNotFoundException;
	public double calculateInterest(int loanId) throws SQLException,InvalidLoanException,ClassNotFoundException;
	public String loanStatus(int loadId) throws SQLException,ClassNotFoundException,InvalidLoanException ;
	public double calculateEMI(int loanId) throws SQLException,ClassNotFoundException,InvalidLoanException;
	public  int loanRepayment(int loanId, double amount) throws InvalidLoanException,SQLException, ClassNotFoundException;
	public List<Loan> getAllLoan() throws SQLException,ClassNotFoundException,InvalidLoanException;
	public Loan getLoanById(int loanId) throws SQLException,ClassNotFoundException,InvalidLoanException;
	
	
}
