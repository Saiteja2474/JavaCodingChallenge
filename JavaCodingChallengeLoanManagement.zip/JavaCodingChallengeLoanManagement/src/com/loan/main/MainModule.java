package com.loan.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.loan.entity.Loan;
import com.loan.service.ILoanRepositoryService;
import com.loan.service.LoanRepositoryServiceImpl;

public class MainModule {

	public static void main(String[] args) {

		
		int loanId;
		
		ILoanRepositoryService loanService = new LoanRepositoryServiceImpl();
		
		int choice = -1;
		
		Scanner scInput = new Scanner(System.in);
		
		while(choice!=0) {
			
			System.out.println("Choose below options:");
			System.out.println("1.Apply Loan ");
			System.out.println("2.Calculate Interest ");
			System.out.println("3. Loan Status ");
			System.out.println("4. Calculate EMI ");
			System.out.println("5. Loan Repayment");
			System.out.println("6. Get All the loans");
			System.out.println("7. Get loan by ID ");
			
			choice = scInput.nextInt();
			System.out.println("Enter your choice:");
			
			switch(choice) {
			
			case 1:
				
				break;
			
			
			case 2:
				
				double interest;
				System.out.println("Enter the loan ID:");
				loanId = scInput.nextInt();
				         scInput.nextLine();
				interest = loanService.calculateInterest(loanId);
				
				System.out.println("Your Interest is "+interest);
				break;
				
			case 3:
				
				String loanStatus;
				
				System.out.println("Enter loan id:");
				int loadId = scInput.nextInt();
				        scInput.nextLine();
				        
				loanStatus = loanService.loanStatus(loadId);
				
				System.out.println("Your loan status is "+loanStatus);
				break;
			case 4:
				int loanId4 =0;
				double emi = 0.0;
				System.out.print("Enter loan ID: ");
                loanId4 = scInput.nextInt();
				emi = loanService.calculateEMI(loanId4);
				
				if (emi==0.0) {
				System.out.println("Loan Not Found");
				}else {
					System.out.println("your EMI is "+emi);
				}
				
				break;
				
			case 5:
				
				int noOfemi = 0;
				int loanId5 =0;
				System.out.print("Enter loan ID: ");
                loanId5 = scInput.nextInt();
                System.out.println("Enter the amount");
                double amount = scInput.nextDouble();
                scInput.nextLine();
                
                noOfemi =  loanService.loanRepayment(loanId5, amount);
                
                if (noOfemi >0) {
                	System.out.println("No.of EMIs can be paid "+noOfemi);
                }
                
                break;
                
			case 6:
				
				List<Loan>loanList=new ArrayList<>();
				
				System.out.println("All loans are:");
				
				loanList = loanService.getAllLoan();
				
				for(Loan loan1:loanList) {
					System.out.println(loan1);
				}
				
				break;
				
			case 7:
				
				Loan loan = null;
				int loanId7 = 0;
				System.out.print("Enter loan ID: ");
				loanId7 = scInput.nextInt();
				loan = loanService.getLoanById(loanId7);
				System.out.println(loan);
				
				break;	
			
				
				
	}
			

   }
 }
}
