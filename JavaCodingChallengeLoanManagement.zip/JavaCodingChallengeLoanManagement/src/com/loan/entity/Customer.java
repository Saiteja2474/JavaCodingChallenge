package com.loan.entity;

import java.util.Objects;

public class Customer {
	
	private int customerId;
	private String name;
	private String email;
	private String phoneno;
	private String address;
	private int creditScore;
	
	public Customer() {
		super();
	}

	public Customer(String name, String email, String phoneno, String address, int creditScore) {
		super();
		this.name = name;
		this.email = email;
		this.phoneno = phoneno;
		this.address = address;
		this.creditScore = creditScore;
	}

	public Customer(int customerId, String name, String email, String phoneno, String address, int creditScore) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.email = email;
		this.phoneno = phoneno;
		this.address = address;
		this.creditScore = creditScore;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(int creditScore) {
		this.creditScore = creditScore;
	}

	@Override
	public int hashCode() {
		return Objects.hash(address, creditScore, customerId, email, name, phoneno);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(address, other.address) && creditScore == other.creditScore
				&& customerId == other.customerId && Objects.equals(email, other.email)
				&& Objects.equals(name, other.name) && Objects.equals(phoneno, other.phoneno);
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", email=" + email + ", phoneno=" + phoneno
				+ ", address=" + address + ", creditScore=" + creditScore + "]";
	}
	
	

}
